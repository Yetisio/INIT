namespace Object_oriented_programming
{
    public interface IPantograph
    {
         string PantographUp();

         string PantographDown();
    }
}